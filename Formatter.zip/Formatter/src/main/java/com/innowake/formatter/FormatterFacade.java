package com.innowake.formatter;

// Class that provides a formatter based on a type
// implements singleton pattern to ensure there is only a single instance
public class FormatterFacade {

	private static FormatterFacade INSTANCE;
	
	private FormatterFacade() {
		//Needed for Singleton 
	}
	
	public static FormatterFacade getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new FormatterFacade();
		}
		return INSTANCE;
	}
	
	
	public Formatter getFormatter(int type) {
		if (type == FormatterType.DATE) {
			return new DateFormatter();
		} else if (type == FormatterType.EMPLOYEE) {
			return new EmployeeFormatter();
		} else {
			return null;
		}
	}
}
