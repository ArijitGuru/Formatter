package com.innowake.formatter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// formatter for dates
public class DateFormatter extends Formatter {

	@Override
	public String format(Object object) {
		data = (Date) object;
		return data.toString();
	}

	@Override
	public Date parse(String text) {
		try {
			data = getDateFormat().parse(text);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
			data = null;
		}
		return (Date) data;
	}

	@Override
	public boolean isValid(String text) {
		boolean status = false;
		try {
			data = getDateFormat().parse(text);
			status = true;
		} catch (ParseException e) {
			System.out.println(e.getMessage());
			status = false;
		}
		return status;
	}
	
	// returns the date format for this formatter
	public DateFormat getDateFormat() {
		return sdf;
	}
	
	
	//Takes text and Locale as input and constructs a Date Object
	public Date parseWithLocale (String text, Locale locale) {
		SimpleDateFormat simpleDateFormat = null;
		if (null != locale) {
			simpleDateFormat = new SimpleDateFormat("EEE, d MMMM yyyy", locale);
		}else {
			simpleDateFormat = new SimpleDateFormat("EEE, d MMMM yyyy");
		}
		
		try {
			data = simpleDateFormat.parse(text);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
			data = null;
		}
		return (Date) data;
		
	}
	

}
