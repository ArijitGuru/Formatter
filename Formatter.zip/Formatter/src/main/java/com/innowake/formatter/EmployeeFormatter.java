package com.innowake.formatter;

import java.util.regex.PatternSyntaxException;

import com.innowake.customtype.Employee;

// formatter for Employees
// expected format: "firstname#lastname#ssn"
public class EmployeeFormatter extends Formatter {

	@Override
	public String format(Object object) {
		data = (Employee) object;
		StringBuffer buffer = new StringBuffer();
		buffer.append(((Employee) data).firstName);
		buffer.append("#");
		buffer.append(((Employee) data).lastName);
		buffer.append("#");
		buffer.append(((Employee) data).ssn);
		return buffer.toString();
	}

	@Override
	public Employee parse(String text) {
		Employee employee = null;
		if (null != text) {
			try {
				employee = new Employee();
				employee.firstName = text.split("#")[0];
				employee.lastName = text.split("#")[1];
				employee.ssn = text.split("#")[2];
			} catch (PatternSyntaxException pse) {
				System.out.println(pse.getDescription());
				employee = null;
			}

		}
		return employee;
	}

	@Override
	public boolean isValid(String text) {
		return parse(text) != null;
	}

}