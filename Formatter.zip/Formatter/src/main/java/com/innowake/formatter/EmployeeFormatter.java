package com.innowake.formatter;

import java.util.regex.PatternSyntaxException;

import com.innowake.customtype.Employee;

// formatter for Employees
// expected format: "firstname#lastname#ssn"
public class EmployeeFormatter extends Formatter {

	@Override
	public String format(Object object) {
		data = (Employee) object;
		StringBuffer buffer = new StringBuffer();
		buffer.append(((Employee) data).getFirstName());
		buffer.append("#");
		buffer.append(((Employee) data).getLastName());
		buffer.append("#");
		buffer.append(((Employee) data).getSsn());
		return buffer.toString();
	}

	@Override
	public Employee parse(String text) {
		Employee employee = null;
		if (null != text) {
			try {
				employee = new Employee();
				employee.setFirstName(text.split("#")[0]);
				employee.setLastName(text.split("#")[1]);
				employee.setSsn(text.split("#")[2]);
			} catch (PatternSyntaxException pse) {
				System.out.println(pse.getDescription());
				employee = null;
			}

		}
		return employee;
	}

	@Override
	public boolean isValid(String text) {
		return parse(text) != null;
	}

}