package com.innowake.formatter;

// the types of formatters
public interface FormatterType {

	public static int DATE = 0;
	public static int EMPLOYEE = 1;
}
