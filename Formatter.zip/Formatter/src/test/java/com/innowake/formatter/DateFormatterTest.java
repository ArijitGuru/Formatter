package com.innowake.formatter;
import java.util.Date;
import java.util.Locale;

import com.innowake.formatter.DateFormatter;
import com.innowake.formatter.FormatterFacade;
import com.innowake.formatter.FormatterType;

public class DateFormatterTest {

	public static DateFormatter dateFormatter = (DateFormatter) FormatterFacade.getInstance().getFormatter(FormatterType.DATE);

	public static void main(String[] args) {
		
		System.out.println("isValid(\"Wed, 4 Jul 2001\"): " + dateFormatter.isValid("Wed, 4 Jul 2001"));

		System.out.println("isValid(\"foo\"): " + dateFormatter.isValid("foo"));
		
		System.out.println("format(new Date()): " + dateFormatter.format(new Date()));
		
		System.out.println("parse(\"Wed, 4 Jul 2001\"): " + dateFormatter.parse("Wed, 4 Jul 2001"));	
		
		System.out.println("parseWithLocale(\"Mittwoch, 16 November 2016\"): " + dateFormatter.parseWithLocale("Mittwoch, 16 November 2016", new Locale("de")));	
		
		System.out.println("parseWithLocale(\"Wed, 4 Jul 2001\"): " + dateFormatter.parseWithLocale("Wed, 4 Jul 2001", null));
	}

}
